
# inputs
from datetime import datetime
import numpy as np

# Dates
TRADE_DATE = datetime(2024, 11, 23)
EXPIRY_DATE = datetime(2025, 5, 10)

# Market inputs
S0 = 19.0        # Spot
K = 17.0         # Strike
r_simple = 0.005 # Simple rate
sigma = 0.30     # Volatility
q = 0.0          # Dividend yield

# Time to maturity
T = (EXPIRY_DATE - TRADE_DATE).days / 365

# Continuous rate
r = np.log(1 + r_simple)

# Test spots
TEST_SPOTS = {
    "OTM": 14.0,
    "ATM": 17.0,
    "ITM": 22.0
}

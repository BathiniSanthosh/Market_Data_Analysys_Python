
# test_black_scholes
import numpy as np
from inputs import *
from models import *

#Spot Price Positivity Test

def spot_price_positive():
    S0 = 100
    if S0 > 0:
        print("PASS: Spot price is positive.")
    else:
        print("FAIL: Spot price is not positive.")


#Spot Equals Strike (ATM)

def spot_equals_strike():
    S0 = 100
    K = 200
    if S0 == K:
        print("PASS: Spot price equals strike price (ATM).")
    else:
        print("FAIL: Spot price is not ATM.")

#Deep In‑The‑Money Spot Case

def spot_deep_in_the_money():
    S0 = 200
    K = 100
    if S0 > K:
        print("PASS: Spot is Deep In_The_Money.")
    else:
        print("FAIL: Spot is not Deep In_The_Money.")

#Deep Out‑Of‑The‑Money Spot Case

def spot_out_of_the_money():
    S0 = 50
    K = 100
    if S0 < K:
        print("PASS: Spot is Deep Out_Of_The_Money.")
    else:
        print("FAIL: Spot is not Out_Of_The_Money.")

    
#Forward Price Consistency

def forward_price_from_spot():
    S0 = 100
    r = 0.05
    T = 1
    forward_price = S0 * np.exp(r * T)

    if forward_price > S0:
        print("PASS: Forward price is greater than spot price.")
    else:
        print("FAIL: Forward pricing logic is incorrect.")

#Spot at Expiry (No Discounting Effect)


def spot_at_expiry():
    S0 = 110
    K = 100
    payoff = max(S0 - K, 0)

    if payoff == 10:
        print("PASS: Spot payoff at expiry is correct.")
    else:
        print("FAIL: Spot payoff at expiry is incorrect.")

    
#Spot Sensitivity Test


def spot_price_increase():
    S0_old = 100
    S0_new = 120
    if S0_new > S0_old:
        print("PASS: Spot price increases correctly.")
    else:
        print("FAIL: Spot price sensitivity failed.")



def test_put_call_parity():
    call = call_spot(S0, K, r, T, sigma)
    put = put_spot(S0, K, r, T, sigma)
    if np.isclose(call - put, S0 - K * np.exp(-r * T)):
        print("PASS: Put_Call Parity holds.")
    else:
        print("FAIL: Put_Call Parity violated.")


def test_forward_vs_spot():
    F = forward_price(S0, r, T)
    call_fwd = call_forward(F, K, r, T, sigma)
    call_sp = call_spot(S0, K, r, T, sigma)
    if np.isclose(call_fwd, call_sp):
        print("PASS: Forward_based and spot_based call prices match.")
    else:
        print("FAIL: Forward vs Spot pricing mismatch.")


def test_greeks_bounds():
    assert 0 <= delta_call(S0, K, r, sigma, T) <= 1
    assert gamma(S0, K, r, sigma, T) > 0
    assert vega(S0, K, r, sigma, T) > 0

def test_mc_convergence():
    call_bs = call_spot(S0, K, r, T, sigma)
    call_mc = mc_call(S0, K, r, sigma, T)
    if abs(call_bs - call_mc) < 0.2:
        print("PASS: Monte Carlo price converges to Black_Scholes.")
    else:
        print("FAIL: Monte Carlo convergence failed.")

    

def output_greeks_bounds(S0, K, r, sigma, T):
    if 0 <= delta_call(S0, K, r, sigma, T) <= 1:
        print("PASS: Call delta within bounds.")
    else:
        print("FAIL: Call delta out of bounds.")

    if gamma(S0, K, r, sigma, T) > 0:
        print("PASS: Gamma is positive.")
    else:
        print("FAIL: Gamma is not positive.")

    if vega(S0, K, r, sigma, T) > 0:
        print("PASS: Vega is positive.")
    else:
        print("FAIL: Vega is not positive.")
        if __name__ == "__main__":
            spot_price_positive()
            spot_equals_strike()
            spot_deep_in_the_money()
            spot_out_of_the_money()
            forward_price_from_spot()
            spot_at_expiry()
            spot_price_increase()
            test_put_call_parity()
            test_forward_vs_spot()
            test_greeks_bounds()
            test_mc_convergence()
            output_greeks_bounds()
print(" All unit tests passed successfully")


def run_spot_tests():
    print("\n--- Running Spot-Related Tests ---\n")

    print(" Spot Price Positivity Test")
    spot_price_positive()

    print("\n Spot Equals Strike (ATM) Test")
    spot_equals_strike()

    print("\n Deep In-The-Money Spot Test")
    spot_deep_in_the_money()

    print("\n Deep Out-Of-The-Money Spot Test")
    spot_out_of_the_money()

    print("\n Forward Price from Spot Test")
    forward_price_from_spot()

    print("\n Spot at Expiry Test")
    spot_at_expiry()

    print("\n Spot Price Sensitivity Test")
    spot_price_increase()

    print("\n All spot-related output tests executed successfully.\n")


if __name__ == "__main__":
    run_spot_tests()

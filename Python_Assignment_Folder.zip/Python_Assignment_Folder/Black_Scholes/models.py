
import numpy as np
from scipy.stats import norm

# Calculations 

def forward_price(S, r, T):
    return S * np.exp(r * T)

#d1 / d2

def d1_spot(S, K, r, sigma, T):
    return (np.log(S / K) + (r + 0.5 * sigma**2) * T) / (sigma * np.sqrt(T))

def d2_from_d1(d1, sigma, T):
    return d1 - sigma * np.sqrt(T)

def d1_forward(F, K, sigma, T):
    return (np.log(F / K) + 0.5 * sigma**2 * T) / (sigma * np.sqrt(T))

#Black–Scholes Pricing 

def call_spot(S, K, r, T, sigma):
    d1 = d1_spot(S, K, r, sigma, T)
    d2 = d2_from_d1(d1, sigma, T)
    return S * norm.cdf(d1) - K * np.exp(-r * T) * norm.cdf(d2)

def put_spot(S, K, r, T, sigma):
    call = call_spot(S, K, r, T, sigma)
    return call - S + K * np.exp(-r * T)

def call_forward(F, K, r, T, sigma):
    d1 = d1_forward(F, K, sigma, T)
    d2 = d2_from_d1(d1, sigma, T)
    return np.exp(-r * T) * (F * norm.cdf(d1) - K * norm.cdf(d2))

#Greeks

def delta_call(S, K, r, sigma, T):
    return norm.cdf(d1_spot(S, K, r, sigma, T))

def delta_put(S, K, r, sigma, T):
    return delta_call(S, K, r, sigma, T) - 1

def gamma(S, K, r, sigma, T):
    d1 = d1_spot(S, K, r, sigma, T)
    return norm.pdf(d1) / (S * sigma * np.sqrt(T))

def vega(S, K, r, sigma, T):
    d1 = d1_spot(S, K, r, sigma, T)
    return S * norm.pdf(d1) * np.sqrt(T)

#Monte Carlo

def mc_call(S, K, r, sigma, T, n_sim=200_000):
    Z = np.random.normal(0, 1, n_sim)
    ST = S * np.exp((r - 0.5 * sigma**2) * T + sigma * np.sqrt(T) * Z)
    return np.exp(-r * T) * np.maximum(ST - K, 0).mean()

def mc_put(S, K, r, sigma, T, n_sim=200_000):
    Z = np.random.normal(0, 1, n_sim)
    ST = S * np.exp((r - 0.5 * sigma**2) * T + sigma * np.sqrt(T) * Z)
    return np.exp(-r * T) * np.maximum(K - ST, 0).mean()

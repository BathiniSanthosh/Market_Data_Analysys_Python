
from inputs import *
from models import *

def run_base_case():
    print("\n BASE CASE (Spot Formulation) ")
    call = call_spot(S0, K, r, T, sigma)
    put = put_spot(S0, K, r, T, sigma)

    print(f"Call Price : {call:.4f}")
    print(f"Put  Price : {put:.4f}")

    print("\n GREEKS ")
    print(f"Delta Call : {delta_call(S0, K, r, sigma, T):.4f}")
    print(f"Delta Put  : {delta_put(S0, K, r, sigma, T):.4f}")
    print(f"Gamma      : {gamma(S0, K, r, sigma, T):.4f}")
    print(f"Vega       : {vega(S0, K, r, sigma, T):.4f}")

def run_itm_atm_otm():
    print("\n ITM / ATM / OTM ")
    for label, S in TEST_SPOTS.items():
        call = call_spot(S, K, r, T, sigma)
        put = put_spot(S, K, r, T, sigma)
        print(f"{label} | Spot={S:>5} | Call={call:6.3f} | Put={put:6.3f}")

def run_mc_validation():
    print("\n MONTE CARLO vs BLACK–SCHOLES ")
    call_bs = call_spot(S0, K, r, T, sigma)
    put_bs = put_spot(S0, K, r, T, sigma)

    call_mc = mc_call(S0, K, r, sigma, T)
    put_mc = mc_put(S0, K, r, sigma, T)

    print(f"Call BS={call_bs:.4f} | Call MC={call_mc:.4f}")
    print(f"Put  BS={put_bs:.4f} | Put  MC={put_mc:.4f}")

if __name__ == "__main__":
    run_base_case()
    run_itm_atm_otm()
    run_mc_validation()

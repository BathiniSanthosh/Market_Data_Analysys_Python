
#Volatility Calculations
import numpy as np
import pandas as pd

def calculate_daily_volatility(df: pd.DataFrame, col: str) -> float:
    return df[col].std()


def calculate_annual_volatility(daily_vol: float) -> float:
    return daily_vol * np.sqrt(252)


import numpy as np
import pandas as pd

def preprocess_data(df: pd.DataFrame) -> pd.DataFrame:
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values(by='date')
    return df


def compute_log_returns(df: pd.DataFrame) -> pd.DataFrame:
    
    """
    Standard log returns used for volatility
    """
    df['log_return1'] = np.log(df['market_rate1'] / df['market_rate1'].shift(1))
    df['log_return2'] = np.log(df['market_rate2'] / df['market_rate2'].shift(1))
    return df


def compute_shift_returns(df: pd.DataFrame) -> pd.DataFrame:
    """
    Shift-based returns used for PnL
    """
    df['market_rate1_shift'] = (
        np.exp(np.log(df['market_rate1'] / df['market_rate1'].shift(-1))) - 1
    )

    df['market_rate2_shift'] = (
        np.exp(np.log(df['market_rate2'] / df['market_rate2'].shift(-1))) - 1
    )

    return df


def compute_pnl(df: pd.DataFrame,
                sensitivity_ccy1: float,
                sensitivity_ccy2: float) -> pd.DataFrame:

    df['pnl_vector1'] = df['market_rate1_shift'] * sensitivity_ccy1
    df['pnl_vector2'] = df['market_rate2_shift'] * sensitivity_ccy2
    df['total_pnl'] = df['pnl_vector1'] + df['pnl_vector2']

    return df

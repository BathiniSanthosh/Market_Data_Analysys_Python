
from data_loader import load_csv
from market_calculations import (
    preprocess_data,
    compute_log_returns,
    compute_shift_returns,
    compute_pnl
)
from volatility import calculate_daily_volatility, calculate_annual_volatility
from option_pricing import black_scholes_call

DATA_PATH = "RawData.csv"

SENSITIVITY_CCY1 = 153084.81
SENSITIVITY_CCY2 = 95891.51

def main():
    df = load_csv(DATA_PATH)
    print(" CSV Loaded Successfully")

    df = preprocess_data(df)

    #  REQUIRED FIX
    df = compute_log_returns(df)
    df = compute_shift_returns(df)

    df = compute_pnl(df, SENSITIVITY_CCY1, SENSITIVITY_CCY2)

    print("\nPnl Results (Top 5)")
    print(df[['pnl_vector1', 'pnl_vector2', 'total_pnl']].head())

    #  Volatility now works
    daily_vol1 = calculate_daily_volatility(df, 'log_return1')
    daily_vol2 = calculate_daily_volatility(df, 'log_return2')

    annual_vol1 = calculate_annual_volatility(daily_vol1)
    annual_vol2 = calculate_annual_volatility(daily_vol2)

    print("\nVolatility Metrics")
    print(f"Daily Vol1: {daily_vol1:.6f}")
    print(f"Daily Vol2: {daily_vol2:.6f}")
    print(f"Annual Vol1: {annual_vol1:.2%}")
    print(f"Annual Vol2: {annual_vol2:.2%}")

    call_price = black_scholes_call(19, 17, 0.46, 0.005, 0.30)
    print(f"\nBlack-Scholes Call Price: {call_price:.4f}")

if __name__ == "__main__":
    main()

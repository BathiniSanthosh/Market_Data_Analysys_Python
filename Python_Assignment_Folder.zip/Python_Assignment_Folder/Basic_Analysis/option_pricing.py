#Black‑Scholes Module

import numpy as np
from scipy.stats import norm
from math import erf, sqrt, exp


def black_scholes_call(S, K, T, r, sigma):
    d1 = (np.log(S / K) + (r + 0.5 * sigma**2) * T) / (sigma * np.sqrt(T))
    d2 = d1 - sigma * np.sqrt(T)

    return S * norm.cdf(d1) - K * np.exp(-r * T) * norm.cdf(d2)


def norm_cdf(x):
    return 0.5 * (1 + erf(x / sqrt(2)))

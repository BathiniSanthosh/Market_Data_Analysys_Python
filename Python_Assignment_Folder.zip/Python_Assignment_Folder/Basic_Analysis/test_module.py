
import unittest
from option_pricing import black_scholes_call
from data_loader import load_csv
import os


class TestBlackScholes(unittest.TestCase):

    def test_call_price_positive(self):
        price = black_scholes_call(19, 17, 0.46, 0.005, 0.30)
        self.assertGreater(price, 0)


class TestCSVLoader(unittest.TestCase):

    def test_missing_file(self):
        with self.assertRaises(FileNotFoundError):
            load_csv("missing.csv")


if __name__ == "__main__":
    unittest.main()

#Market returns

import numpy as np
import pandas as pd

def compute_market_returns(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()

    df["market_rate1_shift"] = np.exp(
        np.log(df["market_rate1"] / df["market_rate1"].shift(-1))
    ) - 1

    df["market_rate2_shift"] = np.exp(
        np.log(df["market_rate2"] / df["market_rate2"].shift(-1))
    ) - 1

    return df

#PnL calculation

def compute_pnl(
    df: pd.DataFrame,
    sensitivity_ccy1: float,
    sensitivity_ccy2: float
) -> pd.DataFrame:

    df = df.copy()

    df["pnl_vector1"] = df["market_rate1_shift"] * sensitivity_ccy1
    df["pnl_vector2"] = df["market_rate2_shift"] * sensitivity_ccy2
    df["total_pnl"] = df["pnl_vector1"] + df["pnl_vector2"]

    return df

#Historical VaR calculation

def calculate_historical_var(
    pnl_series: pd.Series,
    confidence_level: float = 0.99
) -> dict:
    pnl_clean = pnl_series.fillna(0)
    pnl_sorted = np.sort(pnl_clean.values)

    var_percentile = np.percentile(pnl_sorted, (1 - confidence_level) * 100)

    # Excel‑style weighted interpolation
    N = len(pnl_sorted)
    k = (1 - confidence_level) * N
    k_low = int(np.floor(k))
    k_high = int(np.ceil(k))

    w_high = k - k_low
    w_low = 1 - w_high

    var_excel = (
        w_low * pnl_sorted[k_low - 1] +
        w_high * pnl_sorted[k_high - 1]
    )

    var_formula = 0.4 * pnl_sorted[1] + 0.6 * pnl_sorted[2]

    return {
        "var_percentile": var_percentile,
        "var_excel": var_excel,
        "var_formula": var_formula,
        "second_worst": pnl_sorted[1],
        "third_worst": pnl_sorted[2]
    }

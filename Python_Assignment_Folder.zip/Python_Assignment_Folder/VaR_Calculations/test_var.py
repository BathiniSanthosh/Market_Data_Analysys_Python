
import unittest
import pandas as pd
from var_calculations import (
    compute_market_returns,
    compute_pnl,
    calculate_historical_var
)

class TestVaRCalculations(unittest.TestCase):

    def setUp(self):
        self.df = pd.DataFrame({
            "market_rate1": [100, 101, 102],
            "market_rate2": [200, 202, 204]
        })

    def test_market_returns(self):
        df_ret = compute_market_returns(self.df)
        self.assertIn("market_rate1_shift", df_ret.columns)
        self.assertIn("market_rate2_shift", df_ret.columns)

    def test_pnl_calculation(self):
        df = compute_market_returns(self.df)
        df_pnl = compute_pnl(df, 1000, 2000)

        self.assertIn("total_pnl", df_pnl.columns)
        self.assertEqual(len(df_pnl), 3)

    def test_var_output(self):
        pnl = pd.Series([-100, -200, -300, 50, 100])
        results = calculate_historical_var(pnl, 0.99)

        self.assertIn("var_excel", results)
        self.assertIn("var_formula", results)
        self.assertLess(results["var_percentile"], 0)

if __name__ == "__main__":
    unittest.main()

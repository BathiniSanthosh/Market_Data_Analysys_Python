
import pandas as pd

REQUIRED_COLUMNS = ["date", "Portfolio","market_rate1", "market_rate2"]

def load_csv_data(file_path: str) -> pd.DataFrame:
    """
    Load CSV file and validate required columns.
    """
    try:
        df = pd.read_csv(file_path)
    except FileNotFoundError:
        raise FileNotFoundError(f"CSV file not found at path: {file_path}")

    missing_cols = set(REQUIRED_COLUMNS) - set(df.columns)
    if missing_cols:
        raise ValueError(f"Missing required columns: {missing_cols}")

    df["date"] = pd.to_datetime(df["date"], errors="raise")
    df = df.sort_values(by="date")

    return df

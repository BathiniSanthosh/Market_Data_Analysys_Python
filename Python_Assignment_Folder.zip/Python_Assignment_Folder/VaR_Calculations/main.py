
from data_loader import load_csv_data
from var_calculations import (
    compute_market_returns,
    compute_pnl,
    calculate_historical_var
)

FILE_PATH = "C:\\Users\sabathin\\Downloads\\Practice_Assignments\\Python_Assignment_Folder\\VaR_Calculations\\RawData.csv"

SENSITIVITY_CCY1 = 153084.81
SENSITIVITY_CCY2 = 95891.51

def main():
    df = load_csv_data(FILE_PATH)

    df = compute_market_returns(df)
    df = compute_pnl(df, SENSITIVITY_CCY1, SENSITIVITY_CCY2)

    var_results = calculate_historical_var(df["total_pnl"], 0.99)

    print(f"2nd worst PnL: {var_results['second_worst']:,.2f}")
    print(f"3rd worst PnL: {var_results['third_worst']:,.2f}")
    print(f"99% VaR (Percentile): {var_results['var_percentile']:,.2f}")
    print(f"99% VaR (Excel): {var_results['var_excel']:,.2f}")
    print(f"99% VaR (Formula): {var_results['var_formula']:,.2f}")

if __name__ == "__main__":
    main()

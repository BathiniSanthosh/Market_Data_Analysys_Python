
# data_loader
import pandas as pd

REQUIRED_COLUMNS = ["date", "Portfolio","market_rate1", "market_rate2"]

def load_and_prepare_data(csv_path: str) -> pd.DataFrame:
    try:
        df = pd.read_csv(csv_path)

        missing = set(REQUIRED_COLUMNS) - set(df.columns)
        if missing:
            raise ValueError(f"Missing columns: {missing}")

        df["date"] = pd.to_datetime(df["date"], errors="raise")
        df = df.sort_values("date").reset_index(drop=True)

        return df

    except FileNotFoundError:
        raise FileNotFoundError(f"File not found: {csv_path}")

    except Exception as e:
        raise RuntimeError(f"Data loading failed: {e}")

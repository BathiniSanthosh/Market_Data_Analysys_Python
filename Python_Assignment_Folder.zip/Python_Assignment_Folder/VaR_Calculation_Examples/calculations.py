# calculations
import numpy as np
import pandas as pd
from scipy.stats import norm

CONFIDENCE_DEFAULT = 0.99

# ---------------------------
# Returns & PnL
# ---------------------------

def compute_log_returns(df: pd.DataFrame) -> pd.DataFrame:
    df["market_rate1_shift"] = np.exp(
        np.log(df["market_rate1"] / df["market_rate1"].shift(-1))
    ) - 1

    df["market_rate2_shift"] = np.exp(
        np.log(df["market_rate2"] / df["market_rate2"].shift(-1))
    ) - 1

    return df


#PnL calculation

def compute_pnl(
    df: pd.DataFrame,
    sensitivity_ccy1: float,
    sensitivity_ccy2: float
) -> pd.DataFrame:

    df = df.copy()

    df["pnl_vector1"] = df["market_rate1_shift"] * sensitivity_ccy1
    df["pnl_vector2"] = df["market_rate2_shift"] * sensitivity_ccy2
    df["total_pnl"] = df["pnl_vector1"] + df["pnl_vector2"]
    df["total_pnl"] = df["total_pnl"].fillna(0.0)
    return df
# ---------------------------
# VaR Calculations
# ---------------------------

def historical_var(pnl: pd.Series, confidence=CONFIDENCE_DEFAULT):
    return -np.percentile(pnl, (1 - confidence) * 100)


def parametric_var(pnl: pd.Series, confidence=CONFIDENCE_DEFAULT):
    mu, sigma = pnl.mean(), pnl.std()
    z = norm.ppf(confidence)
    return -(mu - z * sigma)


def delta_normal_var(delta1, delta2, vol1, vol2, corr, confidence=CONFIDENCE_DEFAULT):
    z = norm.ppf(confidence)
    portfolio_std = np.sqrt(
        delta1**2 * vol1**2 +
        delta2**2 * vol2**2 +
        2 * delta1 * delta2 * vol1 * vol2 * corr
    )
    return z * portfolio_std


def monte_carlo_var(delta1, delta2, cov, n_sim=100_000, confidence=CONFIDENCE_DEFAULT):
    shocks = np.random.multivariate_normal([0, 0], cov, n_sim)
    pnl_sim = delta1 * shocks[:, 0] + delta2 * shocks[:, 1]
    return -np.percentile(pnl_sim, (1 - confidence) * 100)

# ---------------------------
# Expected Shortfall
# ---------------------------

def expected_shortfall(pnl: pd.Series, confidence=CONFIDENCE_DEFAULT):
    threshold = np.percentile(pnl, (1 - confidence) * 100)
    return -pnl[pnl <= threshold].mean()


def gamma_var(delta1, delta2, gamma1, gamma2, shocks, confidence=CONFIDENCE_DEFAULT):
    pnl = (
        delta1 * shocks[:, 0] + 0.5 * gamma1 * shocks[:, 0]**2 +
        delta2 * shocks[:, 1] + 0.5 * gamma2 * shocks[:, 1]**2
    )
    return -np.percentile(pnl, (1 - confidence) * 100)

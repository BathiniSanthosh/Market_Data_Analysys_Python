
from data_loader import load_and_prepare_data
from calculations import *

CSV_PATH = "C:\\Users\\sabathin\\Downloads\\Practice_Assignments\\Python_Assignment_Folder\\VaR_Calculation_Examples\\RawData.csv"

SENS1 = 153084.81
SENS2 = 95891.51

def main():
    df = load_and_prepare_data(CSV_PATH)
    df = compute_log_returns(df)
    df = compute_pnl(df, SENS1, SENS2)

    pnl = df["total_pnl"]

    var_hist = historical_var(pnl)
    var_param = parametric_var(pnl)
    es_hist = expected_shortfall(pnl)

    vol1 = df["market_rate1_shift"].std()
    vol2 = df["market_rate2_shift"].std()
    corr = df[["market_rate1_shift", "market_rate2_shift"]].corr().iloc[0, 1]

    var_delta = delta_normal_var(SENS1, SENS2, vol1, vol2, corr)

    cov = df[["market_rate1_shift", "market_rate2_shift"]].cov().values
    var_mc = monte_carlo_var(SENS1, SENS2, cov)

    print("Historical VaR:", var_hist)
    print("Parametric VaR:", var_param)
    print("Delta_Normal VaR:", var_delta)
    print("Monte Carlo VaR:", var_mc)
    print("Historical ES:", es_hist)


if __name__ == "__main__":
    main()

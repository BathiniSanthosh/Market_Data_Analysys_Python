import numpy as np
from calculations import historical_var, parametric_var, delta_normal_var, monte_carlo_var


# import unittest
# import numpy as np

# class TestHistoricalVaR(unittest.TestCase):

#     def test_invalid_confidence_high(self):
#         pnl = np.array([-10, -20, -5, 0, 5])
#         with self.assertRaises(
#             ValueError,
#             msg="ValueError should be raised when confidence > 1"
#         ):
#             historical_var(pnl, 1.2)

# if __name__ == "__main__":
#     unittest.main()

import numpy as np

def historical_var(pnl, confidence):
    # Validate confidence level
    if not 0 < confidence <= 1:
        raise ValueError("Confidence level must be between 0 and 1")
  
    pnl = np.asarray(pnl)

    if pnl.size == 0:
        raise ValueError("PnL array must not be empty")

    # Historical VaR is typically the negative α-quantile of losses
    return -np.percentile(pnl, (1 - confidence) * 100)



pnl = np.array([-10, -20, -5, 0, 5])
confidence = 0.95

var_95 = historical_var(pnl, confidence)
print(var_95)


#Parametric VaR function

import numpy as np
from scipy.stats import norm

def parametric_var(pnl, confidence=0.95):
    # Validate confidence level
    if not 0 < confidence <= 1:
        raise ValueError("Confidence level must be between 0 and 1")

    pnl = np.asarray(pnl)

    if pnl.size == 0:
        raise ValueError("PnL array must not be empty")

    mean = np.mean(pnl)
    std = np.std(pnl, ddof=1)

    # Z-score for the confidence level
    z = norm.ppf(1 - confidence)

    # VaR is a positive number (loss)
    var = -(mean + z * std)
    return var

pnl = np.array([-10, -20, -5, 0, 5])
confidence = 0.95

var_95 = parametric_var(pnl, confidence)
print(var_95)

#Delta‑Normal

import numpy as np
from scipy.stats import norm

def delta_normal_var(
    position_1,
    position_2,
    sigma_1,
    sigma_2,
    rho,
    confidence=0.95
):
    # Validate confidence level
    if not 0 < confidence <= 1:
        raise ValueError("Confidence level must be between 0 and 1")

    # Portfolio weights (absolute exposures)
    w = np.array([position_1, position_2])

    # Covariance matrix
    cov = np.array([
        [sigma_1**2, rho * sigma_1 * sigma_2],
        [rho * sigma_1 * sigma_2, sigma_2**2]
    ])

    # Portfolio standard deviation
    portfolio_std = np.sqrt(w.T @ cov @ w)

    # Z-score for left tail
    z = norm.ppf(1 - confidence)

    # VaR is reported as a positive loss
    var = -z * portfolio_std
    return var

position_1 = 100
position_2 = 200
sigma_1 = 0.01
sigma_2 = 0.02
rho = 0.5
confidence = 0.95

var = delta_normal_var(
    position_1,
    position_2,
    sigma_1,
    sigma_2,
    rho,
    confidence
)

print(var)

#Monte Carlo VaR function

import numpy as np

CONFIDENCE_DEFAULT = 0.95

def monte_carlo_var(delta1, delta2, cov, n_sim=100_000, confidence=CONFIDENCE_DEFAULT):
    shocks = np.random.multivariate_normal([0, 0], cov, n_sim)
    pnl_sim = delta1 * shocks[:, 0] + delta2 * shocks[:, 1]

    # Monte Carlo VaR = negative left-tail quantile
    return -np.percentile(pnl_sim, (1 - confidence) * 100)

#Insert values (same style as historical VaR)


# Portfolio deltas
delta1 = 100
delta2 = 200

# Volatilities and correlation
sigma1 = 0.01
sigma2 = 0.02
rho = 0.5

# Covariance matrix
cov = np.array([
    [sigma1**2, rho * sigma1 * sigma2],
    [rho * sigma1 * sigma2, sigma2**2]
])

# Confidence level
confidence = 0.95

#Generate and print the output value

var_mc = monte_carlo_var(delta1, delta2, cov, confidence=confidence)
print(var_mc)

#Test 

def test_monte_carlo_var():
    cov = np.array([
        [0.01**2, 0.5 * 0.01 * 0.02],
        [0.5 * 0.01 * 0.02, 0.02**2]
    ])
    var = monte_carlo_var(100, 200, cov)
    assert var > 0
